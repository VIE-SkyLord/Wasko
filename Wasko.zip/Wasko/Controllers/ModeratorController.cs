using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Wasko.Controllers
{
    [Authorize(Roles = "Kiểm duyệt viên")]
    public class ModeratorController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }
    }
}
