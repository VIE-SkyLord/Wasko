using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Wasko.Data;
using Wasko.Hubs;
using Wasko.Models;

namespace Wasko.Controllers
{
    [Authorize(Roles = "Quản trị viên")]
    public class TopicController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHubContext<NotificationHub> _hubContext;

        public TopicController(ApplicationDbContext context, IHubContext<NotificationHub> hubContext)
        {
            _context = context;
            _hubContext = hubContext;
        }

        public async Task<IActionResult> Index()
        {
            var topics = await _context.ChuDe.ToListAsync();
            return View(topics);
        }

        [HttpPost]
        public async Task<IActionResult> Create(ChuDe topic)
        {
            if (ModelState.IsValid)
            {
                _context.ChuDe.Add(topic);
                await _context.SaveChangesAsync();
                await _hubContext.Clients.Group("Giảng viên").SendAsync("ReceiveNotification", 
                    "Có chủ đề mới", $"Chủ đề mới '{topic.TenChuDe}' đã được thêm vào.");
                return RedirectToAction(nameof(Index));
            }
            return View(topic);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(ChuDe topic)
        {
            if (ModelState.IsValid)
            {
                _context.Update(topic);
                await _context.SaveChangesAsync();
                await _hubContext.Clients.Group("Giảng viên").SendAsync("ReceiveNotification", 
                    "Cập nhật chủ đề", $"Chủ đề '{topic.TenChuDe}' đã được cập nhật.");
                return RedirectToAction(nameof(Index));
            }
            return View(topic);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var topic = await _context.ChuDe.FindAsync(id);
            if (topic != null)
            {
                _context.ChuDe.Remove(topic);
                await _context.SaveChangesAsync();
                await _hubContext.Clients.Group("Giảng viên").SendAsync("ReceiveNotification", 
                    "Xóa chủ đề", $"Chủ đề '{topic.TenChuDe}' đã bị xóa.");
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
