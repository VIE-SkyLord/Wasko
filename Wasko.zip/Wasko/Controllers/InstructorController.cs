using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Wasko.Controllers
{
    [Authorize(Roles = "Giảng viên")]
    public class InstructorController : Controller
    {
        public IActionResult Dashboard()
        {
            return View();
        }
    }
}
