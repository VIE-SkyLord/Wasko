using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using Wasko.Data;
using Wasko.Models;

namespace Wasko.Controllers
{
    [Authorize(Roles = "Giảng viên")]
    public class CourseController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CourseController> _logger;

        public CourseController(ApplicationDbContext context, ILogger<CourseController> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IActionResult InstructorCourseList()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewBag.InstructorId = userId;
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetTopics()
        {
            var topics = await _context.ChuDe.Select(c => new { 
                id = c.Id, 
                name = c.TenChuDe 
            }).ToListAsync();
            return Json(topics);
        }

        [HttpGet]
        public async Task<IActionResult> GetInstructorCourses()
        {
            try 
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return BadRequest(new { success = false, message = "Không tìm thấy thông tin giảng viên" });
                }

                var courses = await _context.KhoaHoc
                    .Where(c => c.IdGiangVien == userId)
                    .Include(c => c.ChuDe)
                    .OrderByDescending(c => c.NgayTao)
                    .Select(c => new {
                        c.IdKhoaHoc,
                        c.TenKhoaHoc,
                        ChuDe = c.ChuDe.TenChuDe,
                        c.CapDo,
                        c.TrangThai,
                        NgayTao = c.NgayTao.ToString("dd/MM/yyyy"),
                        c.GiaKhoaHoc
                    })
                    .ToListAsync();

                return Json(new { success = true, data = courses });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi khi lấy danh sách khóa học");
                return StatusCode(500, new { success = false, message = "Không thể tải danh sách khóa học" });
            }
        }

        [HttpPost] 
        public async Task<IActionResult> Create([FromBody] KhoaHoc course)
        {
            try
            {
                // 1. Lấy và kiểm tra ID giảng viên trước
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return StatusCode(500, new { success = false, message = "Không tìm thấy thông tin giảng viên" });
                }
                
                // 2. Gán ID giảng viên vào course
                course.IdGiangVien = userId;

                // 3. Validate sau khi đã có đủ thông tin
                if (!ModelState.IsValid)
                {
                    var errors = string.Join("; ", ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage));
                    return BadRequest(new { success = false, message = errors });
                }

                // 4. Khởi tạo các collection và null các navigation property
                course.DanhSachBaiHoc = new List<BaiHoc>();
                course.GiangVien = null;
                course.NguoiDuyet = null;
                course.ChuDe = null;

                _context.KhoaHoc.Add(course);
                await _context.SaveChangesAsync();

                return Ok(new { 
                    success = true,
                    message = "Tạo khóa học thành công",
                    courseId = course.IdKhoaHoc 
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { 
                    success = false, 
                    message = $"Lỗi khi tạo khóa học: {ex.Message}" 
                });
            }
        }
    }
}