using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Security.Claims;
using Wasko.Data;
using Wasko.Models;

namespace Wasko.Controllers
{
    [Authorize(Roles = "Giảng viên")]
    public class CourseController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<CourseController> _logger;

        public CourseController(ApplicationDbContext context, ILogger<CourseController> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IActionResult InstructorCourseList()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            ViewBag.InstructorId = userId;
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> GetTopics()
        {
            var topics = await _context.ChuDe.Select(c => new { 
                id = c.Id, 
                name = c.TenChuDe 
            }).ToListAsync();
            return Json(topics);
        }

        [HttpGet("api/Course/instructor/courses")]
        public async Task<IActionResult> GetInstructorCourses()
        {
            try 
            {
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return BadRequest(new { success = false, message = "Không tìm thấy thông tin giảng viên" });
                }

                var courses = await _context.KhoaHoc
                    .Where(c => c.IdGiangVien == userId)
                    .Include(c => c.ChuDe)
                    .OrderByDescending(c => c.NgayTao)
                    .Select(c => new {
                        id = c.IdKhoaHoc,
                        title = c.TenKhoaHoc,
                        topicName = c.ChuDe.TenChuDe,
                        level = c.CapDo,
                        status = c.TrangThai,
                        createdDate = c.NgayTao,
                        price = Convert.ToDouble(c.GiaKhoaHoc) // Convert to double for JSON serialization
                    })
                    .ToListAsync();

                return Json(new { success = true, courses = courses });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi khi lấy danh sách khóa học: {ErrorMessage}", ex.Message);
                _logger.LogError("Stack trace: {StackTrace}", ex.StackTrace);
                return StatusCode(500, new { success = false, message = $"Không thể tải danh sách khóa học: {ex.Message}" });
            }
        }

        [HttpPost] 
        public async Task<IActionResult> Create([FromBody] KhoaHoc course)
        {
            try
            {
                // 1. Lấy và kiểm tra ID giảng viên trước
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    return StatusCode(500, new { success = false, message = "Không tìm thấy thông tin giảng viên" });
                }
                
                // 2. Gán ID giảng viên vào course
                course.IdGiangVien = userId;

                // 3. Validate sau khi đã có đủ thông tin
                if (!ModelState.IsValid)
                {
                    var errors = string.Join("; ", ModelState.Values
                        .SelectMany(v => v.Errors)
                        .Select(e => e.ErrorMessage));
                    return BadRequest(new { success = false, message = errors });
                }

                // 4. Khởi tạo các collection và null các navigation property
                course.DanhSachBaiHoc = new List<BaiHoc>();
                course.GiangVien = null;
                course.NguoiDuyet = null;
                course.ChuDe = null;

                _context.KhoaHoc.Add(course);
                await _context.SaveChangesAsync();

                return Ok(new { 
                    success = true,
                    message = "Tạo khóa học thành công",
                    courseId = course.IdKhoaHoc 
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { 
                    success = false, 
                    message = $"Lỗi khi tạo khóa học: {ex.Message}" 
                });
            }
        }

        [HttpDelete]
        [Route("~/Course/Delete/{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            try
            {
                _logger.LogInformation("Bắt đầu xóa khóa học với ID: {Id}", id);
                
                var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                if (string.IsNullOrEmpty(userId))
                {
                    _logger.LogWarning("Không tìm thấy ID người dùng");
                    return Json(new { success = false, message = "Không tìm thấy thông tin giảng viên" });
                }

                _logger.LogInformation("Đang tìm khóa học với ID: {Id} và IdGiangVien: {UserId}", id, userId);
                
                int courseId;
                if (!int.TryParse(id, out courseId))
                {
                    _logger.LogWarning("ID khóa học không hợp lệ: {Id}", id);
                    return Json(new { success = false, message = "ID khóa học không hợp lệ" });
                }

                var course = await _context.KhoaHoc
                    .Include(c => c.DanhSachBaiHoc) // Thêm include để kiểm tra các bài học liên quan
                    .FirstOrDefaultAsync(c => c.IdKhoaHoc == courseId && c.IdGiangVien == userId);

                if (course == null)
                {
                    _logger.LogWarning("Không tìm thấy khóa học với ID: {Id}", courseId);
                    return Json(new { success = false, message = "Không tìm thấy khóa học" });
                }

                // Kiểm tra xem có bài học nào liên quan không
                if (course.DanhSachBaiHoc != null && course.DanhSachBaiHoc.Count > 0)
                {
                    _logger.LogWarning("Không thể xóa khóa học ID: {Id} vì có {Count} bài học liên quan", courseId, course.DanhSachBaiHoc.Count);
                    return Json(new { success = false, message = "Không thể xóa khóa học vì có bài học liên quan" });
                }

                try
                {
                    _context.KhoaHoc.Remove(course);
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("Đã xóa thành công khóa học với ID: {Id}", courseId);
                    
                    return Json(new { success = true, message = "Xóa khóa học thành công" });
                }
                catch (DbUpdateException dbEx)
                {
                    _logger.LogError(dbEx, "Lỗi khi xóa từ database: {ErrorMessage}", dbEx.Message);
                    return StatusCode(500, new { success = false, message = "Không thể xóa khóa học do có dữ liệu liên quan" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Lỗi không xác định khi xóa khóa học ID {Id}: {ErrorMessage}", id, ex.Message);
                return StatusCode(500, new { success = false, message = "Có lỗi xảy ra khi xóa khóa học" });
            }
        }
    }
}