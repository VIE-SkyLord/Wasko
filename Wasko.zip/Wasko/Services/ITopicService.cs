using Wasko.Models;

namespace Wasko.Services
{
    public interface ITopicService
    {
        IEnumerable<ChuDe> GetAllTopics();
    }
}