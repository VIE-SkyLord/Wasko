using Wasko.Models;

namespace Wasko.Services
{
    public interface ICourseService
    {
        IEnumerable<KhoaHoc> GetCoursesByInstructorId(string instructorId);
    }
}