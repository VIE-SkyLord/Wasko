using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Wasko.Models
{
    public class KhoaHoc
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdKhoaHoc { get; set; }
        
        public int? IdBanGoc { get; set; }
        
        [Required(ErrorMessage = "ID giảng viên là bắt buộc")]
        public string IdGiangVien { get; set; }
        
        [Required(ErrorMessage = "Tên khóa học là bắt buộc")]
        [StringLength(255, ErrorMessage = "Tên khóa học không được vượt quá 255 ký tự")]
        [Display(Name = "Tên khóa học")]
        public string TenKhoaHoc { get; set; }
        
        [Required(ErrorMessage = "Trạng thái khóa học là bắt buộc")]
        [StringLength(50)]
        public string TrangThai { get; set; } = "Chưa xuất bản"; // Giá trị mặc định khi tạo
        
        [StringLength(2000, ErrorMessage = "Mô tả không được vượt quá 2000 ký tự")]
        [Display(Name = "Mô tả khóa học")]
        public string? MoTa { get; set; }
        
        [Required]
        [Column(TypeName = "Date")]
        public DateTime NgayTao { get; set; } = DateTime.Now;
        
        [Column(TypeName = "Date")]
        public DateTime? NgayXuatBan { get; set; }
        
        public string? IdNguoiDuyet { get; set; }
        
        [Column(TypeName = "Date")]
        public DateTime? NgayDuyet { get; set; }
        
        [Required(ErrorMessage = "Chủ đề khóa học là bắt buộc")]
        public int IdChuDe { get; set; }
        
        [Required(ErrorMessage = "Cấp độ khóa học là bắt buộc")]
        [StringLength(50)]
        [Display(Name = "Cấp độ")]
        public string CapDo { get; set; }
        
        [Display(Name = "Số lượng video")]
        public int SoLuongVideo { get; set; } = 0;
        
        [Required(ErrorMessage = "Giá khóa học là bắt buộc")]
        [Range(0, int.MaxValue, ErrorMessage = "Giá khóa học phải lớn hơn hoặc bằng 0")]
        [Display(Name = "Giá khóa học")]
        [Column(TypeName = "decimal(18,2)")]
        public decimal GiaKhoaHoc { get; set; }
        
        [Display(Name = "Đánh giá trung bình")]
        [Range(0, 5, ErrorMessage = "Đánh giá phải từ 0 đến 5 sao")]
        public float SoSaoTrungBinh { get; set; } = 0;

        // Navigation properties
        [ForeignKey("IdGiangVien")]
        public virtual ApplicationUser? GiangVien { get; set; }
        
        [ForeignKey("IdNguoiDuyet")]
        public virtual ApplicationUser? NguoiDuyet { get; set; }
        
        [ForeignKey("IdChuDe")]
        public virtual ChuDe? ChuDe { get; set; }
        
        // Relationship with BaiHoc
        public virtual ICollection<BaiHoc>? DanhSachBaiHoc { get; set; }
    }
    
    public class BaiHoc
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdBaiHoc { get; set; }
        
        [Required]
        public int IdKhoaHoc { get; set; }
        
        [Required]
        [StringLength(255)]
        public string TenBaiHoc { get; set; }
        
        [StringLength(1000)]
        public string MoTa { get; set; }
        
        // Navigation property
        [ForeignKey("IdKhoaHoc")]
        public virtual KhoaHoc KhoaHoc { get; set; }
        
        // Relationships
        public virtual ICollection<TaiLieuHocTap> DanhSachTaiLieu { get; set; }
        public virtual BaiKiemTra BaiKiemTra { get; set; }
    }
    
    public class TaiLieuHocTap
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdTaiLieu { get; set; }
        
        [Required]
        public int IdBaiHoc { get; set; }
        
        [Required]
        [StringLength(50)]
        public string LoaiTaiLieu { get; set; }
        
        [Required]
        [StringLength(255)]
        public string URL { get; set; }
        
        // Navigation property
        [ForeignKey("IdBaiHoc")]
        public virtual BaiHoc BaiHoc { get; set; }
    }
    
    public class BaiKiemTra
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int IdBaiKiemTra { get; set; }
        
        [Required]
        public int IdBaiHoc { get; set; }
        
        [Range(0, 100)]
        public int PhanTramDat { get; set; } = 0;
        
        // Navigation property
        [ForeignKey("IdBaiHoc")]
        public virtual BaiHoc BaiHoc { get; set; }
        
        // Relationship
        public virtual ICollection<CauHoiTracNghiem> DanhSachCauHoi { get; set; }
    }
    
    public class CauHoiTracNghiem
    {
        [Key]
        public int IdCauHoi { get; set; }
        
        [Required]
        public int IdBaiKiemTra { get; set; }
        
        [StringLength(255)]
        public string NoiDungCauHoi { get; set; }
        
        [Required]
        public int IdDapAn { get; set; }
        
        public int DiemCauHoi { get; set; } = 10;
        
        // Navigation property
        [ForeignKey("IdBaiKiemTra")]
        public virtual BaiKiemTra BaiKiemTra { get; set; }
        
        // Relationship
        public virtual ICollection<PhuongAn> DanhSachPhuongAn { get; set; }
    }
    
    public class PhuongAn
    {
        [Key]
        public int IdPhuongAn { get; set; }
        
        [Required]
        public int IdCauHoi { get; set; }
        
        [StringLength(255)]
        public string NoiDungPhuongAn { get; set; }
        
        // Navigation property
        [ForeignKey("IdCauHoi")]
        public virtual CauHoiTracNghiem CauHoi { get; set; }
    }
}
