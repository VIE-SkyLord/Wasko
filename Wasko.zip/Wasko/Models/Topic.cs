public class ChuDe
{
    public int Id { get; set; }
    public string TenChuDe { get; set; }
}